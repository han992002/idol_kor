# legacy of phrecia idol planner

quick and dirty idol planner for the PoE event.

banged this out in a few hours with AI at the wheel - it's absolutely horrendous code, but it (mostly) works.

i do not recommend looking inside.

## remind me how to deploy this thing

```bash
# login & deploy
fly auth login
fly launch
fly deploy
```
